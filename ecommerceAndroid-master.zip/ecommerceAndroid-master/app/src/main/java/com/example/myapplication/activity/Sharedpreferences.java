package com.example.myapplication.activity;

import android.content.SharedPreferences;

public abstract class Sharedpreferences {

    public abstract SharedPreferences getSharedPreferences(String name, int mode);

}
