package com.example.myapplication.adapter;

import androidx.recyclerview.widget.RecyclerView;

public class ProductAdapter  {
}
